# Typing German
  Typing solution for non-German keyboards.
# Default shortcuts
##  Press alt+a / ae to type ä
##  Press alt+o / oe to type ö
##  Press alt+u / ue to type ü
##  Press alt+s / ss to type ß
